.Te aleTi font
.kreated by turos of tempered steel

To install: place the AlethiTS.tff file in the Computer>Windows>Fonts folder.

I suggest you use a font size of at least 72. For most programs, you can type in the font size box to make a custom size.

Special charaters:
For t, use lower case t.
For th, use capital T.
For s, use lower case s.
For sh, use capital S.
For ch, use c.
X will print a combination of k and s.
For q and w, use your imagination. Technically speaking, q is a combination of k and u. W is basically a combination of a long u ("oo") and any other vowel: a e i o and short u ("uh")

In the Alethi alphabet, sentences start with a period '.' and don't end with anything.